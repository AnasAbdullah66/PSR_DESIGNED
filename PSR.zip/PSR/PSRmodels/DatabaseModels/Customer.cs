﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PSRmodels.DatabaseModels
{
    public class Customer
    {
        [Key]
        [Display(Name = "ID")]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int CustomerId { get; set; }

        [StringLength(50)]
        [Required(ErrorMessage = "Customer Name is required")]
        [Display(Name = "Customer Name")]
        public string CustomerName { get; set; }

        [StringLength(50)]
        [Required(ErrorMessage = "Account Number is required")]
        [Display(Name = "Account Number")]
        public string AccountNumber { get; set; }

        [StringLength(50)]
        [Required(ErrorMessage = "Address is required")]
        [Display(Name = "Address")]
        public string Address { get; set; }

        [StringLength(50)]
        [Required(ErrorMessage = "Mobile Number is required")]
        [Display(Name = "Mobile Number")]
        public string MobileNumber { get; set; }
        [Required(ErrorMessage = "Gender is required")]
        [Display(Name = "Gender Number")]
        public int Gender { get; set; }
        public string Brn { get; set; }
        [DataType(DataType.EmailAddress)]
        [Display(Name = "Email")]
        [EmailAddress]
        public string? Email { get; set; }

        [Required(ErrorMessage = "Date of Birth is required")]
        [DataType(DataType.Date)]
        [Column(TypeName = "date")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        [Display(Name = "Date Of Birth")]
        public DateTime DOB { get; set; }
    }

    //[Column(TypeName = "NVARCHAR(MAX)")]
    //[Display(Name = "Profile Picture")]
    //public string? ProfilePicture { get; set; }

}
