﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PSRmodels.DatabaseModels
{
    public class CustomerDocument
    {
        [Key]
        [Display(Name = "ID")]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int CustomerId { get; set; }
        [StringLength(50)]
        [Required(ErrorMessage = "Customer Name is required")]
        [Display(Name = "Customer Name")]
        public string? CustomerName { get; set; }
        public string? AccountNumber { get; set; }
        public string? Address { get; set; }
        public string? MobileNumber { get; set; }
        public int? Gender { get; set; }
        public string? Brn { get; set; }
        public DateTime? DOB { get; set; }
        public string? TinNumber { get; set; }
        public string? AssesmentYear { get; set; }
        public string? Document { get; set; }
        public string? RefNumber { get; set; }
        public DateTime? SubmissionDate { get; set; }
        public int SubUserId { get; set; }
        public string? SubIP { get; set; }
        public DateTime? ProcessDate { get; set; }
        public string? ProcessUser { get; set; }
        public string? ProcessIP { get; set; }
        public string? Status { get; set; }
        public string? Remark { get; set; }
        public string? Location { get; set; }
        public string? BF1 { get; set; }
        public string? BF2 { get; set; }
        public string? BF3 { get; set; }
        public string? BF4 { get; set; }
        public string? BF5 { get; set; }
        public string? BF6 { get; set; }

        //
        public virtual SubUser SubUser { get; set; }
    }
}
