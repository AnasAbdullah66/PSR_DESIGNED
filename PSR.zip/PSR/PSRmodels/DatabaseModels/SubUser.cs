﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PSRmodels.DatabaseModels
{
    public class SubUser
    {
        public int SubUserId { get; set; }
        public string? UserType { get; set; }
    }
}
